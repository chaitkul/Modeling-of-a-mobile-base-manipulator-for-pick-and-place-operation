ENPM 662 - Project 2

Team members:

Name: Chaitanya Kulkarni	
UID: 119183502
Directory ID: chaitkul	

Name: Nirvan Mishra
UID: 119472774
Directory ID: nmishra1

Instructions to run the code:

1. Extract the "chaitkul_nmishra1_proj2.zip" folder and place it in the src folder of your workspace.

2. Build and source the package.

3. For the pick and place operation, use the following commands
	Terminal 1:
		ros2 launch mbm gazebo.launch.py
	Terminal 2:
		cd src/mbm/scripts
		./pub_sub.py

4. For the inverse kinematics validation, use the following commands

	Terminal 1:
		ros2 launch mbm gazebo.launch.py
	Terminal 2:
		cd src/mbm/scripts
		./publisher.py
	The plot of the circular trajectory will be displayed.
	After closing the plot, the robot will execute the same motion

The submission folder contains mbm.zip folder (package), the assembly.zip folder (contains all the parts and assemblies) and the README.md file (contains instructions on how to run the code)

Pick and Place Operation Video Link:

		https://drive.google.com/file/d/1cktaX4M7c6hhhh_KAwj7LxsgRO35Kd7P/view

Inverse Kinematics Validation Video Link:

		https://drive.google.com/file/d/1D-_3VP1yRjRkUxfsM4KeMQRXzCJQeqta/view

5. The video links have also been mentioned in the project report.
